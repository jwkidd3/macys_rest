/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entitytests;

import entity.Customer;
import entity.CustomerTable;
import entity.RelationshipTable;
import entity.Supplier;
import entity.SupplierTable;
import java.util.List;
import java.util.UUID;
import org.junit.Test;
import org.junit.Assert;

/**
 *
 * @author Simon
 */
public class TestFakeDB {

    @Test
    public void testCustomerDataFullSet() {
        List<Customer> lc = CustomerTable.getAll();
        Assert.assertEquals("Sample DB has 7 elements", 7, lc.size());
    }

    @Test
    public void testGetCustomer1ByPK() {
        Customer c = CustomerTable.findByPrimaryKey(new UUID(0, 1));
        Assert.assertEquals("Entry with ID 1 should be Fred Jones",
                "Fred Jones", c.getName());
    }

    @Test
    public void testGetCustomer5ByPK() {
        Customer c = CustomerTable.findByPrimaryKey(new UUID(0, 5));
        Assert.assertEquals("Entry with ID 5 should be Ella Barnard",
                "Ella Barnard", c.getName());
        Assert.assertEquals("Entry with ID 5 should have credit of 800",
                800, c.getCreditLimit());
    }

    @Test
    public void testGetCustomer8ByPK() {
        Customer c = CustomerTable.findByPrimaryKey(new UUID(0, 8));
        Assert.assertNull("Entry with ID 8 should not exist", c);
    }

    @Test
    public void testSuppliersOfFred() {
        List<Supplier> ls = RelationshipTable.findSuppliersOfCustomer(new UUID(0, 1));
        Assert.assertEquals("Fred has 2 suppliers ", 2, ls.size());
        Assert.assertTrue("Fred buys from Floor Mart", ls.contains(SupplierTable.findByPrimaryKey(new UUID(0, 1))));
        Assert.assertTrue("Fred buys from Garden Depot", ls.contains(SupplierTable.findByPrimaryKey(new UUID(0, 3))));
        Assert.assertFalse("Fred does not buy from Bullseye", ls.contains(SupplierTable.findByPrimaryKey(new UUID(0, 2))));
        Assert.assertFalse("Fred does not buy SCCS", ls.contains(SupplierTable.findByPrimaryKey(new UUID(0, 4))));
    }

    @Test
    public void testCustomersOfSCCS() {
        List<Customer> lc = RelationshipTable.findCustomersOfSupplier(new UUID(0, 4));
        Assert.assertEquals("SCCS has 3 customers", 3, lc.size());
        Assert.assertTrue("SCCS sells to Bill", lc.contains(CustomerTable.findByPrimaryKey(new UUID(0, 3))));
        Assert.assertTrue("SCCS sells to Ella", lc.contains(CustomerTable.findByPrimaryKey(new UUID(0, 5))));
        Assert.assertTrue("SCCS sells to Christine", lc.contains(CustomerTable.findByPrimaryKey(new UUID(0, 7))));
    }
    
    @Test
    public void testFindByName() {
        List<Customer> lc = CustomerTable.findByFieldMatch("name", "eq", "Fred Jones");
        Assert.assertEquals("eq match for name Fred Jones should find one element", 1, lc.size());
        Assert.assertEquals("eq match for name Fred Jones should find Fred Jones", "Fred Jones", lc.get(0).getName());
    }
        
    // This test is dubious because the data set is shared. It will potentially fail, or break
    // other tests in the tests are run concurrently.
    @Test
    public void testDeleteAndUpdate() {
        UUID key = new UUID(0, 2);
        Customer c = CustomerTable.findByPrimaryKey(key);
        Customer c1 = CustomerTable.findByPrimaryKey(key);
        Assert.assertNotNull("Get base record should not return null", c1);
        CustomerTable.removeByPrimaryKey(key);
        c1 = CustomerTable.findByPrimaryKey(key);
        Assert.assertNull("Get removed record should return null", c1);
        CustomerTable.update(c);
        c1 = CustomerTable.findByPrimaryKey(key);
        Assert.assertNotNull("Get replaced record should not return null", c1);
    }
}